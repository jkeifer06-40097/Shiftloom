import {days, solve} from './solver.js';
const $ = selector => document.querySelector(selector);
const all = selector => [...document.querySelectorAll(selector)];
const esc = value => String(value).replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'})[ch]);
const week = [0,1,2,3,4,5,6];
const key = 'shiftloom-v1';
const dialog = $('#editor');
const form = $('#edit-form');
function sample() {
  return {
    streak: 4,
    team: [
      ['Avery Chen','Lead',[0,1,2,3,4]], ['Jordan Lee','Lead',[1,2,3,4,5,6]],
      ['Sam Rivera','Lead',[0,4,5,6]], ['Morgan Patel','Crew',[0,1,2,3,4]],
      ['Taylor Brooks','Crew',[1,2,3,4,5]], ['Casey Kim','Crew',[0,3,4,5,6]],
      ['Jamie Diaz','Crew',[0,1,2,5,6]], ['Riley Jones','Crew',[0,1,2,3,4,5,6]]
    ].map(([name, role, available]) => ({name, roles:[role], max:30,
      availability:week.map(d => available.includes(d) ? ['08:00','18:00'] : null)})),
    templates: [
      {name:'Opening lead', role:'Lead', start:'08:00', end:'13:00', days:week, count:1},
      {name:'Morning crew', role:'Crew', start:'08:00', end:'13:00', days:week, count:2},
      {name:'Afternoon crew', role:'Crew', start:'13:00', end:'18:00', days:week, count:1}
    ]
  };
}
let data = sample(), persistFailed = false;
try { data = JSON.parse(localStorage.getItem(key)) || data; } catch { /* Sample remains available. */ }
let result = solve(data.team,data.templates,data.streak);
function save() {
  result = null;
  try { localStorage.setItem(key,JSON.stringify(data)); persistFailed = false; } catch { persistFailed = true; }
  render();
}
function render() {
  const coverage = result?.total ? Math.round(100*result.filled/result.total)+'%' : '—';
  $('#metrics').innerHTML = [[coverage,'Coverage'],[result ? result.filled+' / '+result.total : '—','Staff slots filled'],[data.team.length,'Team members']]
    .map(([value,label]) => `<div class="stat"><span>${label}</span><strong>${value}</strong></div>`).join('');
  $('#status').textContent = (result ? result.total ? result.filled === result.total ? 'All required positions are covered.' :
    result.timedOut ? 'Best schedule found within the search limit. Open positions are shown below.' :
      'Maximum available coverage reached. Open positions are shown below.' : 'Add shift templates to build a roster.' :
    'Inputs updated. Generate a schedule to apply changes.') + (persistFailed ? ' Changes could not be saved in this browser.' : '');
  $('#export').disabled = !result?.rows.length;
  $('#calendar').innerHTML = days.map((day,i) => {
    const rows = result?.rows.filter(row => row.day === i) || [];
    return `<div class="day"><h3>${day}</h3>${rows.length ? rows.map(row => {
      const missing = row.count-row.people.length;
      return `<div class="shift ${missing ? 'gap' : ''}"><strong>${esc(row.name)}</strong>
        <small>${row.start}–${row.end} · ${esc(row.role)}</small>
        ${row.people.map(n => `<span>${esc(data.team[n].name)}</span>`).join('')}
        ${missing ? `<span><b>${missing} open</b></span>` : ''}</div>`;
    }).join('') : '<div class="empty">'+(result ? 'No shifts' : '—')+'</div>'}</div>`;
  }).join('');
  $('#people').innerHTML = records(data.team, person => `${esc(person.roles.join(', '))} · ${person.max} h/week · ${person.availability.map((a,i) => a ? days[i] : null).filter(Boolean).join(', ') || 'Unavailable'}`);
  $('#templates').innerHTML = records(data.templates, s => `${esc(s.role)} · ${s.start}–${s.end} · ${s.count} needed · ${s.days.map(i => days[i]).join(', ')}`);
  $('#streak').value = data.streak;
  $('#add-person').disabled = data.team.length >= 40;
  $('#add-shift').disabled = data.templates.length >= 25;
}
function records(items, details) {
  return items.map((item,i) => `<div class="record"><div><strong>${esc(item.name)}</strong><p>${details(item)}</p></div>
    <div><button class="outline" data-edit="${i}">Edit</button><button class="outline" data-remove="${i}">Remove</button></div></div>`).join('') || '<p class="record">No entries yet.</p>';
}
function role(value) { return value.trim().toLowerCase(); }
function edit(kind,index) {
  const isPerson = kind === 'team';
  const item = data[kind][index] || (isPerson ?
    {name:'',roles:[],max:40,availability:week.map(() => null)} :
    {name:'',role:'',start:'09:00',end:'17:00',count:1,days:week});
  form.innerHTML = `<h2>${index === undefined ? 'Add' : 'Edit'} ${isPerson ? 'team member' : 'shift'}</h2>
    <label>Name <input name="name" required maxlength="48" value="${esc(item.name)}"></label>
    ${isPerson ? `<label>Roles (comma separated) <input name="roles" required maxlength="150" value="${esc(item.roles.join(', '))}"></label>
      <label>Maximum hours per week <input type="number" name="max" required min="0" max="168" step="0.25" value="${item.max}"></label>
      <p>Set both times for each available day. Leave days off blank.</p>
      ${week.map(i => `<div class="availability"><b>${days[i]}</b><input aria-label="${days[i]} available from" type="time" name="from${i}" value="${item.availability[i]?.[0] || ''}"><input aria-label="${days[i]} available until" type="time" name="to${i}" value="${item.availability[i]?.[1] || ''}"></div>`).join('')}` :
    `<label>Required role <input name="role" required maxlength="48" value="${esc(item.role)}"></label>
      <div class="pair"><label>Start <input type="time" name="start" required value="${item.start}"></label><label>End <input type="time" name="end" required value="${item.end}"></label></div>
      <label>Minimum staff <input type="number" name="count" required min="1" max="20" value="${item.count}"></label>
      <p>Repeat on</p><div class="day-picker">${week.map(i => `<label><input type="checkbox" name="days" value="${i}" ${item.days.includes(i) ? 'checked' : ''}> ${days[i]}</label>`).join('')}</div>
      <p>Shifts start and end on the same day.</p>`}
    <p class="error" role="alert"></p>
    <div class="actions"><button class="outline" type="button" id="cancel">Cancel</button><button type="submit" class="primary">Save</button></div>`;
  $('#cancel').onclick = () => dialog.close();
  form.onsubmit = e => {
    e.preventDefault();
    const values = new FormData(form);
    const error = message => { form.querySelector('.error').textContent = message; };
    const name = values.get('name').trim();
    if (!name) return error('Enter a name.');
    let record;
    if (isPerson) {
      const roles = [...new Set(values.get('roles').split(',').map(role).filter(Boolean))];
      if (!roles.length) return error('Enter at least one role.');
      const availability = [];
      for (const i of week) {
        const from = values.get('from'+i), to = values.get('to'+i);
        if ((from || to) && (!from || !to || from >= to)) return error(days[i]+': enter an availability window with an end after its start.');
        availability.push(from ? [from,to] : null);
      }
      record = {name,roles,max:Number(values.get('max')),availability};
    } else {
      const start = values.get('start'), end = values.get('end');
      const requiredRole = role(values.get('role'));
      const selected = values.getAll('days').map(Number);
      if (!requiredRole) return error('Enter a role.');
      if (start >= end) return error('End time must be after start time.');
      if (!selected.length) return error('Select at least one day.');
      record = {name,role:requiredRole,start,end,count:Number(values.get('count')),days:selected};
    }
    if (index === undefined) data[kind].push(record);
    else data[kind][index] = record;
    dialog.close();
    save();
  };
  dialog.showModal();
}
for (const [selector,kind] of [['#people','team'],['#templates','templates']]) {
  $(selector).onclick = event => {
    const btn = event.target.closest('button');
    if (!btn) return;
    if (btn.dataset.edit !== undefined) edit(kind,Number(btn.dataset.edit));
    if (btn.dataset.remove !== undefined) {
      const index = Number(btn.dataset.remove);
      if (confirm('Remove '+data[kind][index].name+'?')) {
        data[kind].splice(index,1);
        save();
      }
    }
  };
}
$('#add-person').onclick = () => edit('team');
$('#add-shift').onclick = () => edit('templates');
$('#streak').onchange = event => {
  if (!event.target.reportValidity()) { event.target.value = data.streak; return; }
  data.streak = event.target.valueAsNumber;
  save();
};
for (const button of all('[data-view]')) button.onclick = () => {
  const view = button.dataset.view;
  all('[data-view]').forEach(b => {
    b.classList.toggle('selected', b === button);
    if (b === button) b.setAttribute('aria-current','page'); else b.removeAttribute('aria-current');
    document.getElementById(b.dataset.view).hidden = b.dataset.view !== view;
  });
  $('#crumb').textContent = button.textContent.trim().slice(1).trim();
};
$('#demo').onclick = () => {
  if (!confirm('Replace your current setup with sample data?')) return;
  data = sample();
  save();
  generate();
};
function generate() { result = solve(data.team,data.templates,data.streak); render(); }
$('#generate').onclick = generate;
function csv(value) {
  let raw = String(value);
  if (/^[\s]*[=+@-]|^[\t\r\n]/u.test(raw)) raw = "'"+raw;
  return '"'+raw.replaceAll('"','""')+'"';
}
$('#export').onclick = () => {
  if (!result) return;
  const rows = [['Day','Shift','Role','Start','End','Assigned','Required','Open']];
  for (const s of result.rows) rows.push([days[s.day],s.name,s.role,s.start,s.end,
    s.people.map(i => data.team[i].name).join('; '),s.count,s.count-s.people.length]);
  const url = URL.createObjectURL(new Blob([rows.map(r => r.map(csv).join(',')).join('\r\n')],{type:'text/csv;charset=utf-8'}));
  const link = document.createElement('a');
  link.href = url; link.download = 'shiftloom-schedule.csv'; link.click();
  setTimeout(() => URL.revokeObjectURL(url),1000);
};
render();
