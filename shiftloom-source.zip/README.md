# Shiftloom

A browser-based workforce scheduler for small teams. Try the preloaded sample,
or edit team members, shifts and scheduling rules. Generate the roster and
export it as CSV. Inputs are stored in the current browser.

## Run locally

With Python 3 installed, run `python -m http.server 8000` in this directory and
open http://localhost:8000. The app has no package dependencies or API keys.
Serve the files on any static host to deploy your own copy. To retain the source
download link, package these files as shiftloom-source.zip alongside index.html.

## Scheduling

The solver uses bounded branch-and-bound search to maximize filled positions.
It respects staff availability windows, required roles, weekly hour limits,
overlap rules, and the maximum number of consecutive Monday–Sunday workdays.
It checks lower-workload staff first and flags uncovered positions. If the
search reaches its time limit, it returns the best assignment found so far.
Availability supports one window per day. Shifts start and end on the same day.

Licensed under Apache 2.0. See LICENSE.
